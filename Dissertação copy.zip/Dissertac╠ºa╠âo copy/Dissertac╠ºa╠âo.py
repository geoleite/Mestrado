print r"Hello \LaTeX!"

